#include "ef.h"

int main(int argc, const char *argv[]) {
    return main_(argc, argv);
}

