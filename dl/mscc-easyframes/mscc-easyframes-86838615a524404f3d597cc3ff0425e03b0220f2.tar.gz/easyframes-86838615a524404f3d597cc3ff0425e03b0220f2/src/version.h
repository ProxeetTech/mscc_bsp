#ifndef VERSION_H
#define VERSION_H

extern const char* gGIT_VERSION;
extern const char* gGIT_VERSION_SHORT;

#endif //VERSION_H
