// Copyright (c) 2020 Microchip Technology Inc. and its subsidiaries.
// SPDX-License-Identifier: MIT

#ifndef _MERA_H_
#define _MERA_H_

#include <microchip/ethernet/rte/api/main.h>

#endif // _MERA_H_
