# pmac

This is a command-line utility for configuring the PMAC table inside MCHP
switches. Currently there is no upstream tool for this operations.

This tool adds features which at the point of designing/implementing
were not present in the upstream kernel. To use these tools, additional
kernel patches are needed, or a pre-patched Microchip kernel is needed.

## How to build

Install build-time dependencies (see CMakeLists.txt)

    $ mkdir build
    $ cd build
    $ cmake ..
    $ make
    $ sudo make install

## Usage

For more details run 'pmac help'

