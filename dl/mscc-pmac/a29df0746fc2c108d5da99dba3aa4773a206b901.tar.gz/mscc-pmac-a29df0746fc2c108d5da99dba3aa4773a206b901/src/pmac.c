/*
 * License: Dual MIT/GPL
 */

#include <getopt.h>
#include <net/if.h>
#include <stdbool.h>
#include <stdint.h>
#include <inttypes.h>
#include <netlink/genl/genl.h>
#include <netlink/genl/ctrl.h>

#include "kernel_types.h"

#define ETH_ALEN		6

#define NEXT_ARG() do { argv++; if (--argc <= 0) pmac_incomplete_command(); } while(0)

#define MCHP_PMAC_NETLINK "mchp_pmac_nl"

enum mchp_pmac_attr {
	MCHP_PMAC_ATTR_NONE,
	MCHP_PMAC_ATTR_IFINDEX,
	MCHP_PMAC_ATTR_MAC,
	MCHP_PMAC_ATTR_VLAN,
	MCHP_PMAC_ATTR_OUI,
	MCHP_PMAC_ATTR_ENTRIES,
	MCHP_PMAC_ATTR_ENTRY,
	MCHP_PMAC_ATTR_ENTRY_INDEX,
	MCHP_PMAC_ATTR_ENTRY_IFINDEXES,
	MCHP_PMAC_ATTR_ENTRY_VLAN,

	/* This must be the last entry */
	MCHP_PMAC_ATTR_END,
};

#define MCHP_PMAC_ATTR_MAX (MCHP_PMAC_ATTR_END - 1)

enum mchp_pmac_genl {
	MCHP_PMAC_GENL_ADD,
	MCHP_PMAC_GENL_DEL,
	MCHP_PMAC_GENL_GET,
	MCHP_PMAC_GENL_PURGE,
};

static struct nla_policy mchp_pmac_genl_policy[MCHP_PMAC_ATTR_END] = {
	[MCHP_PMAC_ATTR_NONE] = { .type = NLA_UNSPEC },
	[MCHP_PMAC_ATTR_MAC] = { .type = NLA_BINARY },
	[MCHP_PMAC_ATTR_IFINDEX] = { .type = NLA_U32 },
	[MCHP_PMAC_ATTR_VLAN] = { .type = NLA_U16 },
	[MCHP_PMAC_ATTR_OUI] = { .type = NLA_U32 },
	[MCHP_PMAC_ATTR_ENTRIES] = { .type = NLA_NESTED },
	[MCHP_PMAC_ATTR_ENTRY] = { .type = NLA_NESTED },
	[MCHP_PMAC_ATTR_ENTRY_INDEX] = { .type = NLA_U16 },
	[MCHP_PMAC_ATTR_ENTRY_IFINDEXES] = { .type = NLA_NESTED },
	[MCHP_PMAC_ATTR_ENTRY_VLAN] = { .type = NLA_U16 },
};

static int pmac_genl_start(const char *family_name, uint8_t cmd,
			   uint8_t version, struct nl_sock **skp,
			   struct nl_msg **msgp)
{
	int err, family_id;

	*skp = nl_socket_alloc();
	if (!*skp) {
		fprintf(stderr, "nl_socket_alloc() failed\n");
		return -1;
	}

	err = genl_connect(*skp);
	if (err < 0) {
		fprintf(stderr, "genl_connect() failed\n");
		goto err_free_socket;
	}

	err = genl_ctrl_resolve(*skp, family_name);
	if (err < 0) {
		fprintf(stderr, "genl_ctrl_resolve() failed\n");
		goto err_free_socket;
	}
	family_id = err;

	*msgp = nlmsg_alloc();
	if (!*msgp) {
		fprintf(stderr, "nlmsg_alloc() failed\n");
		err = -1;
		goto err_free_socket;
	}

	if (!genlmsg_put(*msgp,
			 NL_AUTO_PORT,
			 NL_AUTO_SEQ,
			 family_id,
			 0,
			 NLM_F_REQUEST | NLM_F_ACK,
			 cmd,
			 version)) {
		fprintf(stderr, "genlmsg_put() failed\n");
		goto nla_put_failure;
	}

	return 0;

nla_put_failure:
	nlmsg_free(*msgp);

err_free_socket:
	nl_socket_free(*skp);
	return err;
}

static void pmac_incomplete_command(void)
{
	fprintf(stderr, "Command line is not complete. Try option \"help\"\n");
	exit(-1);
}

static int pmac_parse_args(int argc, char *argv[],
			   char *buf, int *index, int *vlan)
{
	char *addr = NULL;

	*index = -1;
	*vlan = -1;

	while (argc > 0) {
		if (strcmp(*argv, "dev") == 0) {
			NEXT_ARG();
			*index = if_nametoindex(*argv);
		} else if (strcmp(*argv, "vlan") == 0) {
			NEXT_ARG();
			*vlan = atoi(*argv);
		} else {
			if (addr) {
				fprintf(stderr,
					"Duplicate address");
			}
			addr = *argv;
		}
		argc--;
		argv++;
	}

	if (addr == NULL || *index == -1 || *vlan == -1) {
		fprintf(stderr,
			"Error not all arguments are passed\n");
		return -1;
	}

	if (sscanf(addr, "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx",
		   buf, buf+1, buf+2, buf+3, buf+4, buf+5) != 6) {
		fprintf(stderr, "Invalid mac address %s\n", addr);
		return -1;
	}

	return 0;
}


static int pmac_add(int argc, char *argv[])
{
	char addr[ETH_ALEN];
	struct nl_sock *sk;
	struct nl_msg *msg;
	int index;
	int vlan;
	int ret;

	ret = pmac_parse_args(argc, argv, addr, &index, &vlan);
	if (ret)
		return ret;

	ret = pmac_genl_start(MCHP_PMAC_NETLINK,
			      MCHP_PMAC_GENL_ADD, 1, &sk, &msg);
	if (ret < 0)
		return ret;

	NLA_PUT_U32(msg, MCHP_PMAC_ATTR_IFINDEX, index);
	NLA_PUT(msg, MCHP_PMAC_ATTR_MAC, ETH_ALEN, addr);
	NLA_PUT_U16(msg, MCHP_PMAC_ATTR_VLAN, vlan);

	ret = nl_send_auto(sk, msg);
	if (ret < 0) {
		fprintf(stderr, "nl_send_auto() failed, ret: %d\n", ret);
		goto nla_put_failure;
	}

	ret = nl_recvmsgs_default(sk);
	if (ret < 0)
		fprintf(stderr, "nl_recvmsgs_default() failed, ret: %d (%s)\n",
			ret, nl_geterror(ret));

nla_put_failure:
	nlmsg_free(msg);
	nl_socket_free(sk);

	return ret;
}

static int pmac_del(int argc, char *argv[])
{
	char addr[ETH_ALEN];
	struct nl_sock *sk;
	struct nl_msg *msg;
	int index;
	int vlan;
	int ret;

	ret = pmac_parse_args(argc, argv, addr, &index, &vlan);
	if (ret)
		return ret;

	ret = pmac_genl_start(MCHP_PMAC_NETLINK,
			      MCHP_PMAC_GENL_DEL, 1, &sk, &msg);
	if (ret < 0)
		return ret;

	NLA_PUT_U32(msg, MCHP_PMAC_ATTR_IFINDEX, index);
	NLA_PUT(msg, MCHP_PMAC_ATTR_MAC, ETH_ALEN, addr);
	NLA_PUT_U16(msg, MCHP_PMAC_ATTR_VLAN, vlan);

	ret = nl_send_auto(sk, msg);
	if (ret < 0) {
		fprintf(stderr, "nl_send_auto() failed, ret: %d\n", ret);
		goto nla_put_failure;
	}

	ret = nl_recvmsgs_default(sk);
	if (ret < 0)
		fprintf(stderr, "nl_recvmsgs_default() failed, ret: %d (%s)\n",
			ret, nl_geterror(ret));

nla_put_failure:
	nlmsg_free(msg);
	nl_socket_free(sk);

	return ret;
}

static int pmac_read_table(struct nl_msg *msg, void *arg)
{
	struct genlmsghdr *hdr = nlmsg_data(nlmsg_hdr(msg));
	struct nlattr *attrs[MCHP_PMAC_ATTR_END];
	struct nlattr *cur, *ccur;
	int rem, rrem;
	int oui;

	if (nla_parse(attrs, MCHP_PMAC_ATTR_MAX, genlmsg_attrdata(hdr, 0),
		      genlmsg_attrlen(hdr, 0), mchp_pmac_genl_policy)) {
		fprintf(stderr, "Could not get netlink field\n");
		return NL_STOP;
	}

	if (!attrs[MCHP_PMAC_ATTR_OUI])
		return NL_OK;

	oui = nla_get_u32(attrs[MCHP_PMAC_ATTR_OUI]);
	printf("oui: %02x:%02x:%02x\n",
	       (oui >> 16) & 0xff,
	       (oui >> 8) & 0xff,
	       oui & 0xff);

	if (!attrs[MCHP_PMAC_ATTR_ENTRIES])
		return NL_OK;

	nla_for_each_nested(cur, attrs[MCHP_PMAC_ATTR_ENTRIES], rem) {
		 struct nlattr *nattrs[MCHP_PMAC_ATTR_END];
		 int index;

		if (nla_type(cur) != MCHP_PMAC_ATTR_ENTRY)
			continue;

		if (nla_parse_nested(nattrs, MCHP_PMAC_ATTR_MAX, cur,
				     mchp_pmac_genl_policy)) {
			fprintf(stderr, "Could not get embedded netlink\n");
			return NL_STOP;
		}

		index = nla_get_u16(nattrs[MCHP_PMAC_ATTR_ENTRY_INDEX]) % 2048;
		printf("index %04d(%01x:%02x) ",
		       index, (index >> 8) & 0xf, index & 0xff);
		printf("vlan %d ",
		       nla_get_u16(nattrs[MCHP_PMAC_ATTR_ENTRY_VLAN]));

		printf("dest ");
		nla_for_each_nested(ccur, nattrs[MCHP_PMAC_ATTR_ENTRY_IFINDEXES], rrem) {
			char ifname[IFNAMSIZ];

			if (nla_type(ccur) != MCHP_PMAC_ATTR_IFINDEX)
				continue;

			if_indextoname(nla_get_u32(ccur), ifname);
			printf("%s ", ifname);
		}
		printf("\n");
	}

	return NL_OK;
}

static int pmac_get(void)
{
	struct nl_sock *sk;
	struct nl_msg *msg;
	int ret;

	ret = pmac_genl_start(MCHP_PMAC_NETLINK,
			      MCHP_PMAC_GENL_GET, 1, &sk, &msg);
	if (ret < 0)
		return ret;

	nl_socket_modify_cb(sk, NL_CB_VALID, NL_CB_CUSTOM,
			    pmac_read_table, NULL);

	ret = nl_send_auto(sk, msg);
	if (ret < 0) {
		fprintf(stderr, "nl_send_auto() failed, ret: %d\n", ret);
		goto nla_put_failure;
	}

	ret = nl_recvmsgs_default(sk);
	if (ret < 0)
		fprintf(stderr, "nl_recvmsgs_default() failed, ret: %d (%s)\n",
			ret, nl_geterror(ret));

nla_put_failure:
	nlmsg_free(msg);
	nl_socket_free(sk);

	return ret;
}

static int pmac_purge(void)
{
	struct nl_sock *sk;
	struct nl_msg *msg;
	int ret;

	ret = pmac_genl_start(MCHP_PMAC_NETLINK,
			      MCHP_PMAC_GENL_PURGE, 1, &sk, &msg);
	if (ret < 0)
		return ret;

	ret = nl_send_auto(sk, msg);
	if (ret < 0) {
		fprintf(stderr, "nl_send_auto() failed, ret: %d\n", ret);
		goto nla_put_failure;
	}

	ret = nl_recvmsgs_default(sk);
	if (ret < 0)
		fprintf(stderr, "nl_recvmsgs_default() failed, ret: %d (%s)\n",
			ret, nl_geterror(ret));

nla_put_failure:
	nlmsg_free(msg);
	nl_socket_free(sk);

	return ret;
}

static int pmac_help(void)
{
	printf( "\nUsage:\n\n"
		" pmac add LLADDR vlan VID dev DEV \n"
		" pmac del LLADDR vlan VID dev DEV \n"
		" pmac get\n"
		" pmac purge\n\n"
		" Where:\n"
		"  LLADDR is a MAC address\n"
		"  DEV is an interface name\n"
		"  VID is a vlan number\n\n"
		" Examples:\n"
		"  # pmac add 00:11:22:33:44:55 vlan 100 dev eth0\n"
		"\n"
		"  # pmac get\n"
		"  oui: 00:11:22\n"
		"  index 1109(4:55) vlan 100 dest eth0\n"
		"\n"
		"  # pmac add 00:11:22:33:44:66 vlan 100 dev eth0\n"
		"\n"
		"  # pmac get\n"
		"  oui: 00:11:22\n"
		"  index 1109(4:55) vlan 100 dest eth0\n"
		"  index 1126(4:66) vlan 100 dest eth0\n"
		"\n"
		"  # pmac add 00:11:22:33:44:55 vlan 100 dev eth1\n"
		"\n"
		"  # pmac get\n"
		"  oui: 00:11:22\n"
		"  index 1109(4:55) vlan 100 dest eth0 eth1\n"
		"  index 1126(4:66) vlan 100 dest eth0\n"
		"\n"
		"  # pmac add 00:11:22:33:44:55 vlan 200 dev eth1\n"
		"\n"
		"  # pmac get\n"
		"  oui: 00:11:22\n"
		"  index 1109(4:55) vlan 100 dest eth0 eth1\n"
		"  index 1126(4:66) vlan 100 dest eth0\n"
		"  index 1109(4:55) vlan 200 dest eth1\n"
		"\n"
		"  # pmac del 00:11:22:33:44:55 vlan 100 dev eth0\n"
		"\n"
		"  # pmac get\n"
		"  oui: 00:11:22\n"
		"  index 1109(4:55) vlan 100 dest eth1\n"
		"  index 1126(4:66) vlan 100 dest eth0\n"
		"  index 1109(4:55) vlan 200 dest eth1\n"
		"\n"
		"  # pmac purge\n"
		"\n"
		"  # pmac get\n"
		"\n");

	return 0;
}

int main(int argc, char *argv[])
{
	argc--;

	if (argc > 0) {
		argv++;

		if (strcmp(*argv, "add") == 0)
			return pmac_add(argc - 1, argv + 1);
		if (strcmp(*argv, "del") == 0)
			return pmac_del(argc - 1, argv + 1);
		if (strcmp(*argv, "get") == 0)
			return pmac_get();
		if (strcmp(*argv, "purge") == 0)
			return pmac_purge();
		if (strcmp(*argv, "help") == 0)
			return pmac_help();
	} else {
		return pmac_help();
	}

	fprintf(stderr, "Unknown command: %s, try pmac help\n", *argv);

	return -1;
}
