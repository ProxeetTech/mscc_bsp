# spi-reg-access

This tool provides read and write access to the CSR registers in a switch SoC via a SPI interface.
This is used purely for demonstration purposes.

## Access to other register groups than CSR

In Microchip Ethernet Switches other register groups than the CSR group can be accessed indirectly via VCORE_ACCESS.

## Kernel
To use the tool the Linux Kernel must provide a SPI character device that can send and receive data via a SPI controller
in the host.

This may require that the Kernel configuration is changed and most likely that a Device Tree node is added with a
configuration for the SPI host controller and a sub node that lists a SPI device.

Here is an example of a device tree node:


    &flx2 {
        atmel,flexcom-mode = <ATMEL_FLEXCOM_MODE_SPI>;
        status = "okay";

        spi2: spi@400 {
            pinctrl-0 = <&fc2_spi_pins>;
            pinctrl-names = "default";
            cs-gpios = <&gpio 51 GPIO_ACTIVE_LOW>;
            status = "okay";

            spi@0 {
                compatible = "spidev";
                reg = <0>;
                spi-max-frequency = <1000000>;
            };
        };
    };

The SPI controller node refers to 4 GPIOs: Chip Select, SPI Clock, MOSI and MISO (the data lines).

In the example below these are provided via 3 dedicated GPIOs that are configured in a certain alternate mode and
one plain GPIO.

    &gpio {
        fc2_spi_pins: fc2-spi-pins {
            /* SPI - SCLK, MISO, MOSI */
            pins = "GPIO_43", "GPIO_44", "GPIO_45";
            function = "fc2_b";
        };
    };

Finally the physical pin must be connected to the target device.


## Building the tool

The tool can be build using CMAKE like this:

    cd sw-tools-spi-reg-access
    cmake -B build
    ccmake -B build
    cd build
    make

The `ccmake` step allows you to change the default configuration, but this can be skipped.

In case you need to use it on a target with a different architecture than your developer host machine, you must
configure CMAKE to use a cross compiler toolchain.  This is normally done by setting the toolchain define when creating
the project:

    cmake -D CMAKE_TOOLCHAIN_FILE=<path to toolchainfile.cmake> -B build

## Running

When the tool has been installed in the target you can get help like this:

    # spi_reg -h
    Usage: spi_reg spi_dev word_address_hex [new_value_hex]
    Options:
            -h | --help                     Show this help text
            -p | --padding BYTES            Use this number of padding bytes.  Default is 1
            -f | --frequency FREQ_HZ        Clock frequency to use in Hz.  Default is 1MHz

    Examples:
            Reading a value from word address 0x1000:
                    spi_reg /dev/spidev1.0 0x1000

            Writing 0xdeadbeef to word address 0x1002:
                    spi_reg /dev/spidev1.0 0x1002 0xdeadbeef

Now find the name of your spi device:

    # ls -l /dev/spi*
    crw-------    1 root     root      153,   0 Jan  1 00:00 /dev/spidev2.0

Next read the work at work register address 0x1000:

    # spi_reg /dev/spidev2.0 0x1000
    DEV: /dev/spidev2.0, Freq: 1000000, Padding: 1
    RX: 00 10 00-19 66 04 45

Reading the 32-bit word at address 0x1000 returns the value `0x19660445`.

The default settings: padding = 1 (one byte extra is sent to the device to allow it time to respond) and frequency =
1000000 is used to perform the operation.  Normally you do not need to change the default values.

NOTE: The padding byte is not show when the data is displayed in the console.

Please note that the padding is only used when reading and must match the response time that the target device has
otherwise the read result will not be correct.

Writing a value of 0x1234abcd to the address 0x1002 can be done like this:

    # spi_reg /dev/spidev2.0 0x1002 0x1234abcd
    DEV: /dev/spidev2.0, Freq: 1000000, Padding: 1
    Write value: 0x1234abcd
    TX: 80 10 02-12 34 ab cd -> OK
    RX: 00 10 02-12 34 ab cd

Here the tool reads back the updated value and compares it with the value provided on the command line.

