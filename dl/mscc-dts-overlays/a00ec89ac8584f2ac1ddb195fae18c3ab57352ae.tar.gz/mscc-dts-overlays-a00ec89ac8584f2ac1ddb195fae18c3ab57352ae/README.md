dts-overlays
=========

The dts-overlays builds overlays for kernel DT that can be loaded at runtime.

kernel:
=======

First the kernel needs to have the patch
'0001-OF-DT-Overlay-configfs-interface.patch' then it needs to be compiled with
the following config options:

```
CONFIG_OF_CONFIGFS
CONFIG_OVERLAY_FS
CONFIG_OVERLAY_FS_INDEX
CONFIG_OVERLAY_FS_XINO_AUTO
CONFIG_OVERLAY_FS_METACOPY
```

LAN966X already has already the patch and it is compiled with these config
options.

build:
======

To compile single dts
```
gcc -E -Wp,-MD,tmp -nostdinc -I./ -undef -D__DTS__ -x assembler-with-cpp -o tmp2 my_overlay.dts
dtc -o dtb -o my_overlay.dtbo tmp2
```

To compile all dts
```
mkdir build
cd build
cmake ..
```

Then these output files need to be copy to the filesystem.

extend:
=======

To add new overlays just add them at top directory and they just need to have
the extesion .dts

load-dtbo:
==========

```
mount -t configfs none /sys/kernel/config
mkdir -p /sys/kernel/config/device-tree/overlays/tsys01
cat my_overlay.dtbo > /sys/kernel/config/device-tree/overlays/tsys01/dtbo
```
