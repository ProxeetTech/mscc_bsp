#!/bin/bash

die() {
	echo "*** $0 failed :("
	exit 1
}

./clean.sh

automake_flags="-c -a"
for p in aclocal autoconf autoheader automake; do
	flags=${p}_flags
	if ! ${p} ${!flags} ; then
		echo "*** ${p} failed :("
		exit 1
	fi
done

echo
echo "Now just run:"
echo "./configure"
echo "make"
