CMake tools and utilities
=========================

This repository contains common cmake functionality for rt-labs
open-source projects.
