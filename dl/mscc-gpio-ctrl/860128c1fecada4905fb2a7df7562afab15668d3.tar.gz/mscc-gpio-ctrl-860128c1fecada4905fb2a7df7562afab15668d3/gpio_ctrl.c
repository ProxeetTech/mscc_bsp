/*
 * gpio_ctrl - Read or write GPIOs values via a exposed GPIO device
 *
 * Copyright (C) 2021 Microchip
 *
 * Usage:
 *       gpio_ctrl device gpio [value]
 */

#include <unistd.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <dirent.h>
#include <sys/ioctl.h>
#include <linux/types.h>
#include <linux/gpio.h>

#include "missing.h"

#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))

int get_gpio(const char *devname, unsigned int *lines)
{
    struct gpio_v2_line_request req;
    struct gpio_v2_line_values values;
    int fd;
    int ret;

    fd = open(devname, 0);
    if (fd == -1) {
        ret = -errno;
        fprintf(stderr, "Failed to open %s, %s\n", devname, strerror(errno));
        goto exit_error;
    }

    memset(&req, 0, sizeof(req));
    req.offsets[0] = lines[0];
    req.config.flags = GPIO_V2_LINE_FLAG_INPUT;
    req.num_lines = 1;
    strncpy(req.consumer, "gpio_ctrl", GPIO_MAX_NAME_SIZE);

    ret = ioctl(fd, GPIO_V2_GET_LINE_IOCTL, &req);
    if (ret == -1) {
        ret = -errno;
        fprintf(stderr, "Could not request GPIO: %s\n", strerror(errno));
        goto exit_error;
    }
    if (close(fd) == -1) {
        ret = -errno;
        fprintf(stderr, "Failed to close %s, %s\n", devname, strerror(errno));
        goto exit_error;
    }
    fd = req.fd;

    /* The mask defines the selected GPIO lines in the req.offsets */
    values.mask = 1;
    values.bits = 0;
    ret = ioctl(fd, GPIO_V2_LINE_GET_VALUES_IOCTL, &values);
    if (ret == -1) {
        ret = -errno;
        fprintf(stderr, "%s: GPIO: %d, Could not get value: %s\n",
                devname, lines[0], strerror(errno));
        goto exit_close_error;
    }
    fprintf(stdout, "%s: GPIO: %d, value: %d\n", devname, lines[0],
            !!(values.bits & 0x1));
exit_close_error:
    ret = close(fd);
exit_error:
    return ret;
}

int set_gpio(const char *devname, unsigned int *lines, unsigned int value)
{
    struct gpio_v2_line_request req;
    struct gpio_v2_line_values values;
    int fd;
    int ret;

    fd = open(devname, 0);
    if (fd == -1) {
        ret = -errno;
        fprintf(stderr, "Failed to open %s, %s\n", devname, strerror(errno));
        goto exit_error;
    }

    memset(&req, 0, sizeof(req));
    req.offsets[0] = lines[0];
    req.config.flags = GPIO_V2_LINE_FLAG_OUTPUT;
    req.num_lines = 1;
    strncpy(req.consumer, "gpio_ctrl", GPIO_MAX_NAME_SIZE);

    ret = ioctl(fd, GPIO_V2_GET_LINE_IOCTL, &req);
    if (ret == -1) {
        ret = -errno;
        fprintf(stderr, "Could not request GPIO: %s\n", strerror(errno));
        goto exit_error;
    }
    if (close(fd) == -1) {
        ret = -errno;
        fprintf(stderr, "Failed to close %s, %s\n", devname, strerror(errno));
        goto exit_error;
    }
    fd = req.fd;

    /* The mask defines the selected GPIO lines in the req.offsets */
    values.mask = 1;
    values.bits = value;
    ret = ioctl(fd, GPIO_V2_LINE_SET_VALUES_IOCTL, &values);
    if (ret == -1) {
        ret = -errno;
        fprintf(stderr, "%s: GPIO: %d, Could not set value: %s\n",
                devname, lines[0], strerror(errno));
        goto exit_close_error;
    }
    fprintf(stdout, "%s: GPIO: %d, set value: %d\n", devname, lines[0],
            !!(values.bits & 0x1));
exit_close_error:
    ret = close(fd);
exit_error:
    return ret;
}

struct gpio_flag {
    char *name;
    unsigned long long mask;
};

struct gpio_flag flagnames[] = {
    {
        .name = "used",
        .mask = GPIO_V2_LINE_FLAG_USED,
    }, {
        .name = "input",
        .mask = GPIO_V2_LINE_FLAG_INPUT,
    }, {
        .name = "output",
        .mask = GPIO_V2_LINE_FLAG_OUTPUT,
    }, {
        .name = "active-low",
        .mask = GPIO_V2_LINE_FLAG_ACTIVE_LOW,
    }, {
        .name = "open-drain",
        .mask = GPIO_V2_LINE_FLAG_OPEN_DRAIN,
    }, {
        .name = "open-source",
        .mask = GPIO_V2_LINE_FLAG_OPEN_SOURCE,
    }, {
        .name = "pull-up",
        .mask = GPIO_V2_LINE_FLAG_BIAS_PULL_UP,
    }, {
        .name = "pull-down",
        .mask = GPIO_V2_LINE_FLAG_BIAS_PULL_DOWN,
    }, {
        .name = "bias-disabled",
        .mask = GPIO_V2_LINE_FLAG_BIAS_DISABLED,
    }, {
        .name = "clock-realtime",
        .mask = GPIO_V2_LINE_FLAG_EVENT_CLOCK_REALTIME,
    },
};

static void print_attributes(struct gpio_v2_line_info *info)
{
    int i;
    const char *field_format = "%s";

    for (i = 0; i < ARRAY_SIZE(flagnames); i++) {
        if (info->flags & flagnames[i].mask) {
            fprintf(stdout, field_format, flagnames[i].name);
            field_format = ", %s";
        }
    }

    if ((info->flags & GPIO_V2_LINE_FLAG_EDGE_RISING) &&
        (info->flags & GPIO_V2_LINE_FLAG_EDGE_FALLING))
        fprintf(stdout, field_format, "both-edges");
    else if (info->flags & GPIO_V2_LINE_FLAG_EDGE_RISING)
        fprintf(stdout, field_format, "rising-edge");
    else if (info->flags & GPIO_V2_LINE_FLAG_EDGE_FALLING)
        fprintf(stdout, field_format, "falling-edge");

    for (i = 0; i < info->num_attrs; i++) {
        if (info->attrs[i].id == GPIO_V2_LINE_ATTR_ID_DEBOUNCE)
            fprintf(stdout, ", debounce_period=%dusec",
                    info->attrs[0].debounce_period_us);
    }
}

int list_device(const char *device_name)
{
    struct gpiochip_info chpinfo;
    char chrdev_name[128];
    int fd;
    int ret;
    int i;

    ret = sprintf(chrdev_name, "/dev/%s", device_name);
    if (ret < 0)
        return -ENOMEM;

    fd = open(chrdev_name, 0);
    if (fd == -1) {
        ret = -errno;
        fprintf(stderr, "Failed to open %s\n", chrdev_name);
        return ret;
    }

    /* Get info from GPIO chip device */
    ret = ioctl(fd, GPIO_GET_CHIPINFO_IOCTL, &chpinfo);
    if (ret == -1) {
        ret = -errno;
        fprintf(stderr, "Failed get GPIO chip info\n");
        goto exit_close_error;
    }
    fprintf(stdout, "  GPIO chip: %s, \"%s\", %u GPIO lines\n",
            chpinfo.name, chpinfo.label, chpinfo.lines);

    /* Loop over the GPIOs on the chip */
    for (i = 0; i < chpinfo.lines; i++) {
        struct gpio_v2_line_info lineinfo;

        memset(&lineinfo, 0, sizeof(lineinfo));
        lineinfo.offset = i;

        ret = ioctl(fd, GPIO_V2_GET_LINEINFO_IOCTL, &lineinfo);
        if (ret == -1) {
            ret = -errno;
            fprintf(stderr, "Failed get GPIO chip line info\n");
            goto exit_close_error;
        }
        fprintf(stdout, "\tline %2d:", lineinfo.offset);
        if (lineinfo.name[0])
            fprintf(stdout, " \"%s\"", lineinfo.name);
        else
            fprintf(stdout, " unnamed");
        if (lineinfo.consumer[0])
            fprintf(stdout, " \"%s\"", lineinfo.consumer);
        else
            fprintf(stdout, " unused");
        if (lineinfo.flags) {
            fprintf(stdout, " [");
            print_attributes(&lineinfo);
            fprintf(stdout, "]");
        }
        fprintf(stdout, "\n");

    }

exit_close_error:
    if (close(fd) == -1)
        fprintf(stderr, "Failed to close GPIO character device file");
    return ret;
}

static int check_prefix(const char *str, const char *prefix)
{
    return strlen(str) > strlen(prefix) &&
        strncmp(str, prefix, strlen(prefix)) == 0;
}

static void print_devices(void)
{
    const struct dirent *ent;
    DIR *dp;

    fprintf(stderr, "\n\nList of GPIO devices:\n");
    dp = opendir("/dev");
    if (!dp) {
        return;
    }
    while (ent = readdir(dp), ent) {
        if (check_prefix(ent->d_name, "gpiochip")) {
            if (list_device(ent->d_name))
                break;
        }
    }
    closedir(dp);
}

void print_usage(void)
{
    fprintf(stderr, "Usage: gpio_ctrl device gpio [value]\n"
            "\n"
            "Read or write GPIOs values via a exposed GPIO device\n"
            "\n"
            "Write value to GPIO 2 on gpiochip0:\n"
            "	gpio_ctrl /dev/gpiochip0 2 1\n"
            "Read value from GPIO 2 on gpiochip0:\n"
            "	gpio_ctrl /dev/gpiochip0 2\n"
           );
    print_devices();
}

int main(int argc, char **argv)
{
    const char *devname = NULL;
    unsigned int lines[1];
    unsigned int value = 0;

    if (argc < 3) {
        print_usage();
        return -1;
    }
    devname = argv[1];
    lines[0] = strtoul(argv[2], NULL, 10);
    if (argc == 4) {
        value = strtoul(argv[3], NULL, 10);
        return set_gpio(devname, lines, value);
    }
    return get_gpio(devname, lines);
}

/* vim: set ts=4 sw=4 sts=4 tw=120 et cc=120 ft=c :*/
