// Copyright (c) 2020 Microchip Technology Inc. and its subsidiaries.
// SPDX-License-Identifier: (GPL-2.0)

#ifndef LINUX_H
#define LINUX_H

#define ETH_P_MRP 0x88E3

#endif
